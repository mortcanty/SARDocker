void estdop(char file[],int nDopLines, float *a, float *b,float *c);
void yaxb(float x_vec[], float y_vec[],int n, float * a,float * b);
void yax2bxc(float x_vec[],float y_vec[],int n,float *a,float *b,float *c);
