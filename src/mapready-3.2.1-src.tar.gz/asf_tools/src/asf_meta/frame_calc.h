#ifndef _FRAME_CALC_H_
#define _FRAME_CALC_H_

int asf_frame_calc(char *sensor, float latitude, char orbit_direction);

#endif
