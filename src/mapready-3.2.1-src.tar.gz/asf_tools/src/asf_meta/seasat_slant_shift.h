// This is an empirically determined value that improves the
// geolocation in SEASAT data.

#define SEASAT_SLANT_SHIFT -1000.0
