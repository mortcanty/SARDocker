/* Some very basic types and values that get used by lots of things.  */

#ifndef BASIC_TYPES_H
#define BASIC_TYPES_H

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (!FALSE)
#endif

#endif /* BASIC_TYPES_H */
