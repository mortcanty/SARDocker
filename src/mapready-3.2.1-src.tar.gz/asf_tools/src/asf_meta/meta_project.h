#ifndef _META_PROJECT_H_
#define _META_PROJECT_H_

void atct_init_from_leader(const char *leaderName, meta_projection *proj);

#endif // _META_PROJECT_H_
